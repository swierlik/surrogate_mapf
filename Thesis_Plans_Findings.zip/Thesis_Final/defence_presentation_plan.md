# Defence Presentation Plan
**Accelerating Lifelong MAPF Optimization via Uncertainty-Based Surrogate-Assisted Evolution Strategies**
~10 minutes | Audience: data scientists, no MAPF background | Format: figure-heavy

---

## Overall Arc

> "Optimizing a robot warehouse takes 9.5 hours per run. We built a surrogate pipeline to speed it up, got a 2.81x result, then diagnosed that the gain comes from emitter focusing rather than surrogate ranking — and identified landscape roughness as the real open problem."

---

## Slide-by-Slide Breakdown

---

### Slide 1 — Title

**Title:** Accelerating Lifelong MAPF Optimization via Uncertainty-Based Surrogate-Assisted Evolution Strategies

**Visual:** Clean title slide. Name, university, supervisor, date.

---

### Slide 2 — Hook / Motivation (45 s)

**Title:** "9.5 hours to optimize a robot warehouse"

**Visual:** Warehouse robots graphic. Below it, large text:
> **150,000 simulations. 9.5 hours. Per run.**

**What you say:**
- These are real robot warehouses — Amazon, Ocado. Hundreds of robots, continuous delivery tasks.
- The state-of-the-art optimizer (GGO, Zhang et al. 2024) uses an evolutionary algorithm to learn traffic rules for the robots.
- To score a single candidate set of rules, you must run a full multi-agent simulation: 5 seeds, 1000 steps each.
- A standard run needs 150,000 such evaluations. That is 9.5 hours on 8 cores.
- This makes it too slow for live warehouses where layouts or goals change frequently.

---

### Slide 3 — Research Questions (30 s)

**Title:** "Three questions"

**Visual:** Three numbered bullets, clean layout. Leave space — you will return to answer them at the end.

1. How can a surrogate model be integrated into the CMA-ES loop for throughput prediction?
2. How much does pre-screening reduce computation time?
3. What structural conditions make surrogate pre-screening feasible at all?

**What you say:**
- These are the three questions that drove the work. I will answer all three at the end.
- The third one turned out to be the most interesting.

---

### Slide 4 — GGO: What a Solution Looks Like (45 s)

**Title:** "What are we optimizing?"

**Visual:** Directional weight heatmap — five panels (Left, Right, Up, Down, Wait), each showing the warehouse map as a grid with weights normalized 0–100. Darker = stronger directional preference. The horizontal shelf structure is clearly visible.

**What you say:**
- The warehouse floor is a directed graph. Every edge between two cells gets a scalar flow weight — 4,074 weights in total.
- Robots use those weights as soft directional preferences when choosing paths.
- The optimizer's job is to find the weight vector that maximises throughput — mean tasks completed per timestep.
- This figure shows an already-optimized solution: you can see the optimizer has learned directionality, guiding robots along the main aisles rather than across them.
- Now — how does the optimizer find this?

---

### Slide 5 — CMA-ES (45 s)

**Title:** "How we search: CMA-ES"

**Visual:** Simple diagram showing a multivariate Gaussian distribution over solution space, with arrows showing it shifting toward higher-quality regions each generation. Optionally show 5 separate distributions for 5 emitters.

**What you say:**
- CMA-ES is an evolutionary algorithm. It maintains a probability distribution over possible weight vectors and samples candidates from it each generation.
- The top-performing candidates update the distribution so it shifts toward better regions. Repeat for 300 generations.
- We use a multi-emitter variant: 5 independent distributions running in parallel, each proposing 20 candidates per generation = 100 candidates total.
- Different emitters explore different regions of the 4,074-dimensional space simultaneously.
- Each candidate must be scored by running the full warehouse simulation — that is the bottleneck.

---

### Slide 6 — Baseline Convergence (30 s)

**Figure:** fig3_baseline_convergence.png

**Title:** "What vanilla CMA-ES achieves"

**What you say:**
- Vanilla CMA-ES converges smoothly to around 8.2 tasks per step over 300 generations.
- Each generation costs 500 simulation runs (100 candidates × 5 seeds).
- 300 generations = 150,000 simulations = 9.5 hours.
- That is the quality and cost we are working with.

---

### Slide 7 — Before and After (30 s)

**Title:** "From random to optimized"

**Visual:** Two-panel occupancy heatmap (fig_occupancy_heatmap.png). Left: generation 0 random solution, throughput = 3.62. Right: optimized solution, throughput = 8.38. Darker = more agent visits per cell.

**What you say:**
- This is what that convergence looks like in practice.
- On the left: a random set of weights. Agents are spread across the warehouse with no clear structure.
- On the right: after 300 generations of CMA-ES. Traffic concentrates along the efficient paths the optimizer discovered, throughput goes from ~3.5 to ~8.2 tasks per step.
- GGO works. The only problem is the 9.5 hours.

---

### Slide 8 — Breaker (10 s)

**Title:** "That was GGO — already published work."

**Visual:** Simple full-screen text slide, bold, minimal. Something like:

> **GGO:** Zhang et al., IJCAI 2024
>
> **Now: what we did.**

**What you say:**
- Everything up to here is the prior work we are building on.
- From this slide forward — this is the contribution of this thesis.

---

### Slide 9 — The Surrogate Pipeline (60 s)

**Title:** "Replace 80% of simulations with an MLP"

**Visual:** The flowchart figure (fig2_flowchart.png) or the inline diagram:
```
Each generation:
│
├─ CMA-ES proposes 100 candidates
│
├─ [SURROGATE] Score all 100 cheaply
│     score = μ(x) + λ·σ(x)   ← UCB
│
├─ Top 20 → real simulator
│
└─ Fine-tune surrogate on 20 new results
```

**What you say:**
- The surrogate is an ensemble of 5 bootstrapped MLPs trained on past (solution, throughput) pairs.
- Each generation: score all 100 proposals with the surrogate in microseconds, send only the top 20 to the real simulator.
- The UCB score adds a bonus for high-uncertainty candidates — this guards against the surrogate being over-trusted in regions it has not seen. The gradient refinement experiment confirms this failure mode is real without UCB.
- Three phases: a warmup of 20 full-evaluation generations, then alternating surrogate and periodic full-evaluation control generations.

---

### Slide 10 — Main Result (90 s)

**Figure:** fig4_sample_efficiency.png

**Title:** "2.81x fewer simulations, same quality"

**What you say:**
- X-axis: cumulative simulation calls. Y-axis: best throughput found so far.
- Vanilla CMA-ES (blue) needs 137,000 simulations to first cross the τ = 8.23 threshold.
- Surrogate V3 (orange) crosses the same threshold at 49,000 simulations.
- That is a 2.81x crossover speedup — same final quality, 65% fewer real simulations.
- Wall-clock time drops from 9.5 hours to 3.5 hours.
- Consistent across a second random seed: 2.92x. So the result is not a lucky draw.

---

### Slide 11 — Why Does It Work? (90 s)

**Figure:** fig11_rho_emitter_structure.png

**Title:** "We got 2.81x — then we asked why"

**What you say:**
- We could have stopped at the speedup number. Instead we asked: why does this work at all?
- The figure has two panels.
- **Top panel:** per-emitter mean throughput over generations. Emitter 2 (red, ★) diverges to ~8.2 while emitters 0, 1, 3, 4 all plateau near 5.1. That is a 3-unit gap against a within-emitter standard deviation of 0.17.
- At that signal-to-noise ratio the surrogate does not need to predict precise fitness values. It only needs to sort candidates into two buckets: emitter 2 or not. Any model can do that, even in 4,074 dimensions.
- **Bottom panel:** tracks the ratio of between-emitter variance to total variance over generations. When this is near 1, almost all population diversity comes from between-emitter differences and the sorting task is easy. When it is near 0, all emitters cluster together and any ranking is noise.
- Orange: vanilla run, divergence grows gradually as emitters naturally separate. Red dashed: surrogate run, saturates near 1 by generation 40 because UCB concentrates budget on emitter 2.
- The surrogate is not predicting fitness. It is sorting candidates by emitter. That is why it works.

---

### Slide 12 — When It Fails: Single-Emitter (60 s)

**Title:** "But a single emitter beats it"

**Visual:** A simple comparison table or two numbers side by side:
```
Vanilla 5-emitter:      137,000 sims  (1.00x)
Surrogate V3:            49,000 sims  (2.81x)
Single-emitter, no ML:   41,500 sims  (3.30x)
```

**What you say:**
- To check whether the surrogate is actually doing useful work, we ran a one-emitter CMA-ES with population size 100 and no surrogate at all.
- It reaches the same threshold at 41,500 simulations — a 3.30x speedup, beating V3's 2.81x.
- The surrogate's efficiency gain comes from implicit emitter starvation, not from ranking quality within an emitter.
- ICC = 0 in a single-emitter run by construction. So why can't a better model still rank within an emitter?

---

### Slide 13 — Diagnostic Tests + Architecture Comparison (90 s)

**Visual:** Table III from the thesis — all architectures, median ρ.

**Title:** "Landscape roughness is the bottleneck"

**What you say:**
- We ran three diagnostic tests on a single-emitter baseline to isolate the cause of the ρ ≈ 0 result.
  - **Capacity test:** XGBoost achieves ρ = 0.999 when trained and tested on the same generation. Model capacity is not the problem.
  - **Oracle test:** Train on 80% of the same generation, test on the other 20% — both XGBoost and MLP collapse to ρ ≈ 0. Distribution shift is not the problem.
  - **Noise bound:** Theory gives a ceiling of ρ ≤ 0.99. Measurement noise is not the problem.
- The only remaining explanation: within one emitter's distribution, candidates are so similar that knowing 80 of them tells you nothing about the other 20. This is landscape roughness.
- We tested four architectures — MLP, LargeCNN, CellTransformer, GNN — to check whether a richer model could overcome this. Table: best result is LargeCNN at median ρ = 0.17, far below the ρ > 0.8 needed for reliable screening.
- This is a necessary condition **given raw weight inputs**. The open question is whether different input representations — graph-based features, power iteration on the adjacency matrix — can expose smoother structure.

---

### Slide 14 — Conclusions + Research Questions Answered (60 s)

**Title:** "What we found"

**Visual:** Three rows answering the research questions from Slide 3, then one line for future work. No walls of text.

| Question | Answer |
|---|---|
| Q1: How to integrate a surrogate into CMA-ES? | Ensemble MLP + UCB + three-phase loop. It works. |
| Q2: How much does pre-screening help? | 2.81x fewer simulations. But a single-emitter baseline hits 3.30x without any ML. |
| Q3: What structural conditions make it feasible? | Emitter divergence. When one emitter clearly dominates, the surrogate sorts by emitter membership. Without that gap, no architecture helps. |
| Next step | Graph-based feature engineering (power iteration on the adjacency matrix) to expose smoother fitness structure. |

**What you say:**
- Let us go back to the three questions from the start.
- Q1: yes, the pipeline works. Ensemble MLP, UCB scoring, warmup then surrogate then control generations.
- Q2: 2.81x fewer simulations to reach the same quality. But honestly, a single-emitter CMA-ES with no surrogate at all gets to 3.30x. The surrogate does not outperform the simpler baseline on this problem.
- Q3: emitter divergence is what makes it work. When one emitter clearly outperforms the rest, the surrogate's job is just to sort candidates into buckets by emitter. That is a very different task from predicting precise fitness, and it is easy. Without that gap, and we showed this with four different architectures, no model can rank reliably. The bottleneck is landscape roughness in the input representation, not model capacity.
- The concrete next step: graph-based features derived from the warehouse graph topology, fed into the surrogate instead of raw weights. LargeCNN is the most practical starting point.

---

### Slide 15 — Punchline (10 s)

**Title:** none

**Visual:** Single sentence, large, centred, nothing else:

> "We measured 2.81x. Then found 3.30x without any ML. The contribution is knowing why."

**What you say:**
- Just say it. Let it land. Then stop.

---

## Timing Summary

| Slide | Topic | Time |
|---|---|---|
| 1 | Title | — |
| 2 | Hook / motivation | 0:45 |
| 3 | Research questions | 0:30 |
| 4 | GGO — what a solution looks like | 0:45 |
| 5 | CMA-ES explanation | 0:45 |
| 6 | Baseline convergence | 0:30 |
| 7 | Before and after heatmap | 0:30 |
| 8 | Breaker — "now: our work" | 0:10 |
| 9 | Surrogate pipeline | 1:00 |
| 10 | Main result | 1:30 |
| 11 | Why it works — emitter divergence | 1:30 |
| 12 | When it fails — single-emitter | 1:00 |
| 13 | Diagnostic tests + architectures | 1:30 |
| 14 | Conclusions + research questions answered | 1:00 |
| 15 | Punchline | 0:10 |
| **Total** | | **~11:30** |

Still slightly over. Further cuts if needed:
- Slide 7 (before/after) can be dropped — 30 s saved.
- Slides 12 and 13 can be merged into one slide — 30 s saved.
- That brings you to ~10:30, which lands at 10 minutes with a normal pace.

---

## Likely Defence Questions and Suggested Answers

**Q: Why not use Gaussian Processes instead of an MLP ensemble?**
> GPs scale as O(n³) in training data. After 200+ generations we have thousands of (w, τ) pairs in 4,074 dimensions — GPs become computationally prohibitive. The bootstrapped MLP ensemble gives calibrated uncertainty at a fraction of the cost, and its rank correlation (0.78–0.94) is strong enough for pre-screening.

**Q: How do you know the speedup is real and not just because you are picking the best emitter?**
> It is not. A single-emitter baseline with population size 100 and no surrogate reaches the same threshold at 41,500 simulations, a 3.30x reduction, which beats V3's 2.81x. The surrogate's net effect is implicit emitter concentration via UCB starvation, not ranking quality within an emitter. The ICC analysis explains why: once emitters diverge, coarse region identification is enough, and a simple focused search replicates that without the ML overhead.

**Q: What happens if ICC is low?**
> Then per-emitter ρ collapses toward zero and the surrogate cannot rank candidates reliably. The screening step would actively hurt performance by discarding good candidates at random. The ICC figure gives you a generation-by-generation warning sign.

**Q: Would this work in domains other than LMAPF?**
> The pipeline is general: multi-emitter CMA-ES + ensemble MLP + UCB. The only domain-specific assumption is that fitness evaluations are expensive and the population has multi-modal structure (high ICC). Any black-box optimization problem with those two properties is a candidate.

**Q: Why λ=1.0 specifically?**
> Ablation study. λ=0 (pure exploitation) degrades because the surrogate is over-trusted as distributions shift. λ=2.0 over-explores and wastes budget on uncertain but poor candidates. λ=1.0 balances the two. The quality difference is modest and from a single run — treat it as indicative rather than a precise optimum.

**Q: Is λ=0 vs λ=1 really a meaningful difference if emitter starvation means the dominant emitter gets most of the budget anyway?**
> Partially fair. With extreme starvation, most of the top-20 slots go to emitter 2 regardless of λ, so cross-emitter selection is not the main mechanism. The real risk of λ=0 is that the 80 candidates not simulated still receive surrogate-predicted fitness values that feed into the CMA-ES distribution update. As emitter 2's distribution shifts into new regions, the surrogate has no data there and overestimates fitness — those inflated placeholder values bias the update. UCB counters this by giving high-uncertainty frontier candidates a score bonus. The +1.4% quality gain (8.04 vs 8.15) is modest but consistent with this mechanism.

**Q: Is ICC really a necessary condition, or just an empirical finding with the models you tried?**
> Strong empirical evidence, not a mathematical proof. The three diagnostic tests rule out model capacity, distribution shift, and measurement noise as explanations, leaving landscape roughness as the cause of within-emitter ρ ≈ 0. We tested four architectures including a domain-aware GNN — all failed. The qualifier is: this holds for raw weight inputs. The open question is whether graph-based feature engineering can change that.

**Q: Why is the single-emitter result not in the title or abstract framing more prominently?**
> It is in the abstract and in the Discussion. The framing is: we built a surrogate pipeline, measured 2.81x, then diagnosed the mechanism. The single-emitter result is part of that diagnosis, not a refutation. It tells us where the efficiency actually comes from, which is a genuine contribution — especially because it leads directly to the ICC finding and the feature engineering direction.

---

## Presentation Tips

- **Do not define LMAPF in formal terms** — say "robots in a warehouse with continuous delivery tasks."
- **Anchor every abstract claim to a number**: "9.5 hours," "2.81x," "49k vs 137k," "3.30x."
- **Slide 11 is the hardest** — practice the emitter divergence explanation until it is conversational. Anchor it to the numbers: "3-unit gap, 0.17 noise — any model can sort these into buckets."
- **The sample efficiency figure (Slide 10) and the emitter divergence figure (Slide 11) are your two key visuals.** If pressed for time, cut slides around these before cutting them.
- **Slides 12 and 13 can be merged** if you are running over time — show the single-emitter comparison and the architecture table on the same slide.
- **Avoid the word 'obviously'** — nothing is obvious to this audience.
- Bring a printed copy of Table I and Table III in case slides fail.
